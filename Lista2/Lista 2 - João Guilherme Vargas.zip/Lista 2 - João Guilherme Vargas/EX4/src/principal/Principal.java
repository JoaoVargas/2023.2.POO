package principal;

import dados.*;

public class Principal {
    public static void main(String[] args) {
        Turma t = new Turma();
    }

}
