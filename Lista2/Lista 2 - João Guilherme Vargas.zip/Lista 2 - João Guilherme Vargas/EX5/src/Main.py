from dados.Filme import Filme

filme = Filme("alo")

print(filme.getTitulo())